﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VersionControl.Diff;

namespace VersionControl.Merge.Text
{

    public class TextMerger : MergerBase<string>
    {
        public TextMerger()
            : base(new StringValueComparer())
        {
        }

        public MergeResult Merge(string original, params string[] versions)
        {
            var linesOfVersions = versions.Select(v => Split(v).ToArray()).ToArray();

            var result = Merge(Split(original).ToArray(), linesOfVersions);
            return result;
        }

        private IEnumerable<string> Split(string s)
        {
            var key = '\n';
            return s.Split(key);
        }
       

        public MergeResult Merge(string[] originalLines, params string[][] versions)
        {
            var context = new MergeResult
            {
                Lines = originalLines.Select(s => (object)s).ToList(),//copy
                Conflicts = new List<Conflict>()
            };

            MergeLines(originalLines, versions, context);
            return context;
        }


        public void MergeLines(string[] originalLines, string[][] versions, MergeResult context)
        {
            var diff = new Diff<string>(Comparer);
            var allCommands = diff.GetDiffFast(originalLines, versions).ToList();
            Merge(context, allCommands);
        }

        protected override bool IsEmptyValue(string value)
        {
            return string.IsNullOrWhiteSpace(value.Trim());
        }
    }
}
