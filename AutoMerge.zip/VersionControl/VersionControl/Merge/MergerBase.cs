﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VersionControl.Merge
{
    public abstract class MergerBase<T>
    {
        protected readonly IComparer<T> Comparer;

        public MergerBase(IComparer<T> comparer)
        {
            this.Comparer = comparer;
        }

        internal void Merge(MergeResult context, List<Command> allCommands)
        {
            var groupedCommands = (from c in allCommands
                                   let lineCmd = c as LineCommand
                                   where lineCmd != null

                                   group c by lineCmd.LineNumber into g
                                   orderby g.Key
                                   select new LineAggregator<T>
                                   {
                                       LineNumber = g.Key,
                                       InsertCommands = g.Where(gc => gc is InsertCommand<T>).Select(gc => (InsertCommand<T>)gc).Distinct(new InsertCommandComparer<T>(Comparer)),
                                       RemoveCommands = g.Where(gc => gc is RemoveCommand).Select(gc => (RemoveCommand)gc).Distinct(new RemoveCommandComparer())
                                   }).ToArray();



            var orderedGroups = from k in groupedCommands
                                orderby k.LineNumber
                                select k;
     

            foreach (var lineGroup in orderedGroups)
            {
                //execute only one remove cmd
                //if it has more than 1 insert -> it's a conflict 
                MergeLine(context, lineGroup);
            }

            var appendCommands = allCommands.Where(c => c is AppendLineCommand<T>);
            foreach (var c in appendCommands)
                c.Execute(context);
         
        }

        protected virtual void MergeLine(MergeResult context, LineAggregator<T> lineGroup)
        {
            var removeCmd = lineGroup.RemoveCommands.SingleOrDefault();
            if (removeCmd != null)
                removeCmd.Execute(context);

            var insertCommands = lineGroup.InsertCommands;
            var realChangeCommands = insertCommands.Where(c => !IsEmptyValue(c.Value));
            //if compare an empty line and a change -> select the change

            if (realChangeCommands.Count() > 1)
            {
                var values = realChangeCommands.OrderBy(c=>c.Version).Select(c => c.Version + " : " + c.Value).ToArray();
                var cmd = new InsertCommand<string>("", lineGroup.LineNumber, "")
                {
                    Value = "Conflict line:" + lineGroup.LineNumber + " " + string.Join(" --- OR --- ", values)
                };

                cmd.Execute(context);

                context.Conflicts.Add(new Conflict
                {
                    Versions = values
                });
            }
            else
            {
                //if it has a change command - ignore all the empty-lined commands
                var change = realChangeCommands.FirstOrDefault();
                if (change != null)
                    change.Execute(context);
                else
                {
                    //ignore multiple empty-lined commands
                    var emptyCommand = insertCommands.Where(c => IsEmptyValue(c.Value)).FirstOrDefault();
                    if (emptyCommand != null)
                        emptyCommand.Execute(context);
                }
            }
        }

        abstract protected bool IsEmptyValue(T value);

    }
}
