﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VersionControl
{
    public abstract class Command
    {
        public string Version;
        abstract public void Execute(MergeResult c);

        public Command(string version)
        {
            this.Version = version;
        }
    }


    public abstract class LineCommand : Command
    {
        public int LineNumber;

        public LineCommand(string version, int lineNmber)
            : base(version)
        {
            this.LineNumber = lineNmber;
        }
    }


    public class InsertCommand<T> : LineCommand
    {
        public T Value;

        public InsertCommand(string version, int lineNmber, T value)
            : base(version, lineNmber)
        {
            this.Value = value;
        }

        public override void Execute(MergeResult c)
        {
            var n = LineNumber + c.Offset +1;
            c.Lines.Insert(n, Value);

            c.Offset++;
        }
    }


    public class AppendLineCommand<T> : Command
    {
        public T Value;

        public AppendLineCommand(string version, T value)
            : base(version)
        {
            this.Value = value;
        }

        public override void Execute(MergeResult c)
        {
            c.Lines.Add(Value);
        }
    }

    public class RemoveCommand : LineCommand
    {
        public RemoveCommand(string version, int lineNmber)
            : base(version, lineNmber)
        {
        }

        public override void Execute(MergeResult c)
        {
            c.Lines.RemoveAt(LineNumber + c.Offset);
            c.Offset--;
        }
    }


}
