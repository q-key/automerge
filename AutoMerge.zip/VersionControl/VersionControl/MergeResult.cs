﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VersionControl.Merge;

namespace VersionControl
{
    public class MergeResult
    {
        public List<object> Lines;
        public List<Conflict> Conflicts;
        internal int Offset;

        public string Text { get { return string.Join("\n", Lines); } }
    }
}
